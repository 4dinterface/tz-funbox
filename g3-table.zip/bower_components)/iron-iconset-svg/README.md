iron-iconset-svg
=========

See the [component page](https://elements.polymer-project.org/elements/iron-iconset-svg) for more information.
